(function () {
  console.log('start bottom js execution');
})();